﻿import os, time, random, threading, csv
from datetime import datetime
os.add_dll_directory(r"C:\Windows\System32")
import pynvml
import torch

DURATION_S = 1200
SEED = 23
LABEL = "lab_random"
OUT = "gpu_telemetry_lab.csv"

pynvml.nvmlInit()
h = pynvml.nvmlDeviceGetHandleByIndex(0)

phase = {"name": "idle"}
stop = threading.Event()

def logger():
    with open(OUT, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["timestamp", "workload_type", "temperature_c", "gpu_utilization_percent",
                    "memory_utilization_percent", "power_watts", "phase"])
        while not stop.is_set():
            t = pynvml.nvmlDeviceGetTemperature(h, pynvml.NVML_TEMPERATURE_GPU)
            u = pynvml.nvmlDeviceGetUtilizationRates(h)
            p = pynvml.nvmlDeviceGetPowerUsage(h) / 1000.0
            w.writerow([datetime.now().strftime("%Y-%m-%d %H:%M:%S"), LABEL, t, u.gpu, u.memory,
                        round(p, 2), phase["name"]])
            f.flush()
            time.sleep(1)

threading.Thread(target=logger, daemon=True).start()

a8 = torch.randn(8192, 8192, device="cuda", dtype=torch.float16)
b8 = torch.randn(8192, 8192, device="cuda", dtype=torch.float16)
a6 = torch.randn(6144, 6144, device="cuda", dtype=torch.float16)
b6 = torch.randn(6144, 6144, device="cuda", dtype=torch.float16)

def run_phase(name, seconds):
    phase["name"] = name
    end = time.time() + seconds
    while time.time() < end:
        if name == "heavy":
            _ = a8 @ b8
            torch.cuda.synchronize()
        elif name == "medium":
            _ = a6 @ b6
            torch.cuda.synchronize()
            time.sleep(0.05)
        else:
            time.sleep(0.5)

rng = random.Random(SEED)
start = time.time()
print("Lab RTX 5090 random run started. Do NOT press Ctrl+C.")
while time.time() - start < DURATION_S:
    name = rng.choices(["heavy", "medium", "idle"], weights=[0.45, 0.2, 0.35])[0]
    secs = rng.randint(10, 60)
    secs = min(secs, max(1, int(DURATION_S - (time.time() - start))))
    print(f"[{int(time.time()-start):4d}s] phase={name} for {secs}s | GPU {pynvml.nvmlDeviceGetTemperature(h, pynvml.NVML_TEMPERATURE_GPU)} C")
    run_phase(name, secs)

phase["name"] = "idle"
time.sleep(2)
stop.set()
time.sleep(1.5)
print("Done. Saved", OUT)
