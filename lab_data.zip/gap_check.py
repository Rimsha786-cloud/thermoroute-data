import csv, sys
from datetime import datetime

fn = sys.argv[1]
rows = list(csv.DictReader(open(fn)))
t = [datetime.strptime(r["timestamp"], "%Y-%m-%d %H:%M:%S") for r in rows]
temp = [float(r["temperature_c"]) for r in rows]

print(fn, "rows:", len(rows))
print("first:", t[0], " last:", t[-1], " span_s:", int((t[-1] - t[0]).total_seconds()))

segs = []
start = 0
for i in range(1, len(t)):
    gap = (t[i] - t[i - 1]).total_seconds()
    if gap > 3:
        print(f"GAP of {gap:.0f}s after row {i} at {t[i-1].time()}  "
              f"(temp {temp[i-1]:.0f} -> {temp[i]:.0f})")
        segs.append((start, i))
        start = i
segs.append((start, len(t)))

print("segments (rows):", [b - a for a, b in segs])
print("max temp:", max(temp), " min temp:", min(temp))