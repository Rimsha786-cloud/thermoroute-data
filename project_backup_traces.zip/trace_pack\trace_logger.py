import sys, time, csv, requests

label = sys.argv[1]
dur = int(sys.argv[2])
ports = {"nodeA": 8011, "nodeB": 8012, "nodeC": 8013}
out = f"trace_{label}.csv"
t0 = time.time()
with open(out, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["policy", "t_s", "node", "temp_c", "power_est_w", "queue"])
    while time.time() - t0 < dur:
        t = round(time.time() - t0, 1)
        for n, p in ports.items():
            try:
                d = requests.get(f"http://127.0.0.1:{p}/telemetry", timeout=2).json()
                w.writerow([label, t, n, d["temp_c"], d["power_est_w"], d["queue"]])
            except Exception:
                pass
        f.flush()
        time.sleep(1)
print("saved", out)