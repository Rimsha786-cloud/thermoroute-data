import copy
import json
import numpy as np
import pandas as pd

SUB = 5  # same sub-stepping as fit_rc2.py, so the nominal model matches the fit

CONFIGS = {
    "nodeA": dict(cool_scale=1.25, amb_offset=0.0),   # good cooling
    "nodeB": dict(cool_scale=1.00, amb_offset=1.0),   # average
    "nodeC": dict(cool_scale=0.80, amb_offset=2.0),   # poor cooling (hot rack slot)
}

def load_params(name="2-part+fan"):
    x = json.load(open("rc_params2.json"))[name]
    return dict(Tamb=x[0], R1=float(np.exp(x[1])), C1=float(np.exp(x[2])),
                R2=float(np.exp(x[3])), C2=float(np.exp(x[4])), a=x[5])

def build_power_table():
    cols = ["gpu_utilization_percent", "power_watts"]
    d = pd.concat([pd.read_csv("gpu_telemetry.csv")[cols],
                   pd.read_csv("gpu_telemetry_random.csv")[cols]])
    d["bin"] = (d["gpu_utilization_percent"] // 10) * 10
    g = d.groupby("bin").agg(u=("gpu_utilization_percent", "mean"),
                             p=("power_watts", "median")).sort_values("u")
    return g["u"].values, np.maximum.accumulate(g["p"].values)

class NodeThermal:
    def __init__(self, params, cool_scale=1.0, amb_offset=0.0, noise_sd=0.3, seed=0, t_init=30.0):
        self.Tamb = params["Tamb"] + amb_offset
        self.R1, self.C1 = params["R1"], params["C1"]
        self.R2, self.C2 = params["R2"], params["C2"]
        self.a = params["a"]
        self.cool = cool_scale
        self.noise_sd = noise_sd
        self.rng = np.random.default_rng(seed)
        self.T1 = t_init + amb_offset
        self.T2 = self.T1 - self.R1 * 25.0

    def step(self, dt, power_w):
        h = dt / SUB
        for _ in range(SUB):
            q12 = (self.T1 - self.T2) / self.R1
            g2 = self.cool * (1 + self.a * max(self.T2 - self.Tamb, 0.0) / 50.0) / self.R2
            self.T1 += h * (power_w - q12) / self.C1
            self.T2 += h * (q12 - (self.T2 - self.Tamb) * g2) / self.C2

    def read_temp(self):
        return int(round(self.T1 + self.rng.normal(0, self.noise_sd)))

class Forecaster:
    """Router-side model: nominal parameters, tracks hidden state from readings."""
    def __init__(self, params):
        self.node = NodeThermal(params, noise_sd=0.0)
        self.started = False

    def observe(self, t_meas, power_w):
        n = self.node
        if not self.started:
            n.T2 = max(n.Tamb, t_meas - n.R1 * power_w)
            self.started = True
        n.T1 = float(t_meas)

    def advance(self, power_w, dt=1.0):
        self.node.step(dt, power_w)

    def predict(self, H, power_future):
        if len(power_future) < H:
            return float("nan")
        n = copy.copy(self.node)
        for j in range(H):
            n.step(1.0, power_future[j])
        return n.T1

if __name__ == "__main__":
    params = load_params()
    ux, py = build_power_table()
    print("util->power table:", [(round(a), round(b)) for a, b in zip(ux, py)])
    pw = lambda u: float(np.interp(u, ux, py))

    print("\n=== TEST 1: constant 100% load for 300 s, then idle for 300 s ===")
    nodes = {k: NodeThermal(params, seed=i, **cfg) for i, (k, cfg) in enumerate(CONFIGS.items())}
    util = np.r_[np.full(300, 100.0), np.zeros(300)]
    traj = {k: [] for k in nodes}
    for u in util:
        for k, n in nodes.items():
            traj[k].append(n.T1)
            n.step(1.0, pw(u))
    for t in [0, 30, 60, 120, 299, 330, 420, 599]:
        print(f"t={t:3d}s  " + "  ".join(f"{k}={traj[k][t]:.1f}C" for k in nodes))

    print("\n=== TEST 2: forecast error on a random load (router model does NOT know node cooling) ===")
    rng = np.random.default_rng(123)
    lv = []
    while len(lv) < 1200:
        lvl = rng.choice([100.0, 21.0, 0.0], p=[0.45, 0.2, 0.35])
        lv += [lvl] * int(rng.integers(10, 61))
    util = np.array(lv[:1200])
    P = np.array([pw(u) for u in util])
    rows = []
    for i_n, (k, cfg) in enumerate(CONFIGS.items()):
        plant = NodeThermal(params, seed=100 + i_n, **cfg)
        fc = Forecaster(params)
        Tm = []
        pred = {10: [], 30: []}
        for i in range(len(P)):
            r = plant.read_temp()
            Tm.append(r)
            fc.observe(r, P[i])
            for H in (10, 30):
                pred[H].append(fc.predict(H, P[i:i + H]))
            plant.step(1.0, P[i])
            fc.advance(P[i])
        Tm = np.array(Tm, dtype=float)
        for H in (10, 30):
            idx = np.arange(5, len(P) - H)
            p = np.array(pred[H])[idx]
            true = Tm[idx + H]
            naive = Tm[idx]
            dyn = np.abs(Tm[idx] - Tm[idx - 5]) >= 2
            rows.append({"node": k, "H": H, "ALL_model": np.abs(p - true).mean(),
                         "ALL_naive": np.abs(naive - true).mean(),
                         "DYN_model": np.abs(p - true)[dyn].mean(),
                         "DYN_naive": np.abs(naive - true)[dyn].mean(),
                         "n_dyn": int(dyn.sum()), "max_T": Tm.max()})
    res = pd.DataFrame(rows).round(2)
    print(res.to_string(index=False))
    res.to_csv("emulator_selftest.csv", index=False)
    print("\nSaved emulator_selftest.csv")