import argparse
import threading
import time
from collections import deque

import pynvml
import torch
import joblib
import pandas as pd
from fastapi import FastAPI
import uvicorn
import os

parser = argparse.ArgumentParser()
parser.add_argument("--port", type=int, required=True)
parser.add_argument("--node-id", type=str, required=True)
args = parser.parse_args()

os.add_dll_directory(r"C:\Windows\System32")
pynvml.nvmlInit()
handle = pynvml.nvmlDeviceGetHandleByIndex(0)

model = joblib.load("temp_predictor_rf.pkl")
MODEL_FEATURE_COLUMNS = model.feature_names_in_.tolist()

HISTORY = deque(maxlen=10)
history_lock = threading.Lock()
device = torch.device("cuda")

# Preallocate tensors once (reused for every /infer call)
SIZE = 8192
a = torch.randn((SIZE, SIZE), device=device, dtype=torch.float16)
b = torch.randn((SIZE, SIZE), device=device, dtype=torch.float16)

def sample_telemetry():
    while True:
        temp = pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU)
        util = pynvml.nvmlDeviceGetUtilizationRates(handle)
        power = pynvml.nvmlDeviceGetPowerUsage(handle) / 1000.0
        with history_lock:
            HISTORY.append({
                "temperature_c": temp,
                "gpu_utilization_percent": util.gpu,
                "memory_utilization_percent": util.memory,
                "power_watts": power,
            })
        time.sleep(1)

def predict_future_temperature():
    with history_lock:
        if len(HISTORY) < 6:
            return None
        current = HISTORY[-1]
        lag = HISTORY[-6]

    row = {col: 0 for col in MODEL_FEATURE_COLUMNS}
    row["temperature_c"] = current["temperature_c"]
    row["gpu_utilization_percent"] = current["gpu_utilization_percent"]
    row["memory_utilization_percent"] = current["memory_utilization_percent"]
    row["power_watts"] = current["power_watts"]
    row["temp_lag"] = lag["temperature_c"]
    row["temp_trend"] = current["temperature_c"] - lag["temperature_c"]

    X = pd.DataFrame([row])[MODEL_FEATURE_COLUMNS]
    return round(float(model.predict(X)[0]), 2)

app = FastAPI()

@app.get("/telemetry")
def telemetry():
    with history_lock:
        if not HISTORY:
            return {"error": "no data yet"}
        current = HISTORY[-1]
    predicted = predict_future_temperature()
    return {
        "node_id": args.node_id,
        "current_temperature_c": current["temperature_c"],
        "predicted_future_temperature_c": predicted,
        "gpu_utilization_percent": current["gpu_utilization_percent"],
        "memory_utilization_percent": current["memory_utilization_percent"],
        "power_watts": current["power_watts"],
    }

@app.post("/infer")
def infer():
    """Simulates handling one AI inference request: runs a heavier real GPU compute burst."""
    start = time.time()
    for _ in range(30):  # simulate a heavier inference workload
        c = torch.matmul(a, b)
    torch.cuda.synchronize()
    latency_ms = round((time.time() - start) * 1000, 2)
    return {"node_id": args.node_id, "status": "completed", "latency_ms": latency_ms}

if __name__ == "__main__":
    threading.Thread(target=sample_telemetry, daemon=True).start()
    uvicorn.run(app, host="127.0.0.1", port=args.port)