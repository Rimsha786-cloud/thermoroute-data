import sys, time
import numpy as np
import pandas as pd
from emulator import load_params, NodeThermal, Forecaster, CONFIGS

PARAMS = load_params()
NODES = list(CONFIGS.keys())
N = len(NODES)

S0 = 0.153                 # s per request (measured on real RTX 5090)
P_IDLE, P_MAX = 30.0, 575.0
SIM_S, WARM = 1000, 200
T_SOFT = 70.0              # policy cap used for the violation metric
T_GUARD = 68.0             # router excludes nodes whose signal >= this
THROTTLE_T, THROTTLE_X = 80.0, 1.25
H = 10
WQ = 1.5   
SLACK = 1.0                # requests of extra queue allowed for thermal choice                # deg C penalty per queued request
ALPHA = 0.1                # bias-correction smoothing
GUARD_MODE = "hard"
WSOFT = 1.0

POLICIES = ["round_robin", "least_load", "reactive", "predictive_raw", "predictive", "reactive_slack", "predictive_slack"]
PATTERNS = ["steady", "bursty", "moderate", "high"]
SEEDS = range(2) if "quick" in sys.argv else range(10)   # test seeds 0-9; tune only on seeds >= 100

def rate_profile(pattern, rng):
    r = np.zeros(SIM_S)
    if pattern == "steady":
        r[:] = 15.0
    elif pattern == "high":
        r[:] = 17.5
    elif pattern == "moderate":
        r[:] = 10.0
    else:
        t, on = 0, True
        while t < SIM_S:
            d = int(rng.integers(20, 61))
            r[t:t + d] = 18.0 if on else 6.0
            t += d
            on = not on
    return r

def add_busy(b, s, e):
    t0 = int(s)
    while t0 < e and t0 < len(b):
        b[t0] += min(e, t0 + 1) - max(s, t0)
        t0 += 1

def run(policy, pattern, seed):
    rng = np.random.default_rng(seed)
    rate = rate_profile(pattern, rng)
    arr_by_sec = [t + np.sort(rng.random(rng.poisson(lam))) for t, lam in enumerate(rate)]
    total = sum(len(a) for a in arr_by_sec)
    jit = np.random.default_rng(seed + 1000).lognormal(0, 0.03, size=total + 5)
    rp = np.random.default_rng(seed + 2000)

    plants = [NodeThermal(PARAMS, seed=seed * 10 + i, **CONFIGS[k]) for i, k in enumerate(NODES)]
    fcs = [Forecaster(PARAMS) for _ in NODES]
    free_at = np.zeros(N)
    busy = np.zeros((N, SIM_S + 60))
    p_prev = np.full(N, P_IDLE)
    p_ewma = np.full(N, P_IDLE)
    bias = np.zeros(N)
    raw_h = [[] for _ in range(N)]
    cor_h = [[] for _ in range(N)]
    e_raw, e_cor = [], []
    Ttrue = np.zeros((N, SIM_S))
    Pw = np.zeros((N, SIM_S))
    lat, fin, arrt = [], [], []
    rr, k = 0, 0
    is_pred = policy.startswith("predictive")

    for t in range(SIM_S):
        reads = np.array([p.read_temp() for p in plants], dtype=float)
        sig = reads.copy()
        if is_pred:
            for i in range(N):
                if t > 0:
                    fcs[i].advance(p_prev[i])
                fcs[i].observe(reads[i], p_prev[i])
                p_ewma[i] = 0.7 * p_ewma[i] + 0.3 * p_prev[i]
                if t >= H:
                    err = reads[i] - raw_h[i][t - H]
                    if t >= WARM:
                        e_raw.append(abs(err))
                        e_cor.append(abs(reads[i] - cor_h[i][t - H]))
                    bias[i] = (1 - ALPHA) * bias[i] + ALPHA * err
                raw = fcs[i].predict(H, [p_ewma[i]] * H)
                raw_h[i].append(raw)
                cor_h[i].append(raw + bias[i])
                sig[i] = raw if policy == "predictive_raw" else raw + bias[i]

        for a in arr_by_sec[t]:
            q = np.maximum(0.0, free_at - a) / S0
            if policy == "round_robin":
                i = rr % N
            elif policy == "least_load":
                i = min(range(N), key=lambda j: (q[j], (j - rr) % N))
            elif policy.endswith("_slack"):
                qmin = q.min()
                cand = [j for j in range(N) if q[j] <= qmin + SLACK]
                i = min(cand, key=lambda j: (sig[j], q[j]))
            else:
                score = sig + WQ * q
                if GUARD_MODE == "soft":
                    score = score + WSOFT * np.maximum(0.0, sig - T_GUARD)
                    cand = list(range(N))
                else:
                    cand = [j for j in range(N) if sig[j] < T_GUARD] or list(range(N))
                i = min(cand, key=lambda j: score[j])
            rr += 1
            svc = S0 * jit[k] * (THROTTLE_X if plants[i].T1 >= THROTTLE_T else 1.0)
            start = max(a, free_at[i])
            end = start + svc
            free_at[i] = end
            add_busy(busy[i], start, end)
            lat.append(end - a); fin.append(end); arrt.append(a)
            k += 1

        for i in range(N):
            frac = min(1.0, busy[i][t])
            p = P_IDLE + (P_MAX - P_IDLE) * frac + rp.normal(0, 3.0)
            Ttrue[i, t] = plants[i].T1
            Pw[i, t] = p
            plants[i].step(1.0, p)
            p_prev[i] = p

    lat, fin, arrt = np.array(lat), np.array(fin), np.array(arrt)
    m = arrt >= WARM
    done = m & (fin <= SIM_S)
    T = Ttrue[:, WARM:]
    res = dict(pattern=pattern, policy=policy, seed=seed,
               mean_T=T.mean(), max_T=T.max(), p99_T=np.percentile(T, 99),
               viol_pct=100 * (T > T_SOFT).mean(),
               throttle_pct=100 * (T >= THROTTLE_T).mean(),
               imbalance_C=T.std(axis=0).mean(),
               p50_ms=1000 * np.percentile(lat[m], 50),
               p95_ms=1000 * np.percentile(lat[m], 95),
               p99_ms=1000 * np.percentile(lat[m], 99),
               thr_rps=done.sum() / (SIM_S - WARM),
               J_per_req=Pw[:, WARM:].sum() / max(done.sum(), 1),
               util_std=busy[:, WARM:SIM_S].clip(max=1).mean(axis=1).std(),
               fc_raw_mae=np.mean(e_raw) if e_raw else np.nan,
               fc_cor_mae=np.mean(e_cor) if e_cor else np.nan)
    for i, kname in enumerate(NODES):
        res["meanT_" + kname] = T[i].mean()
        res["share_" + kname] = (arrt[m] >= 0).sum() * 0 + np.nan  # placeholder, filled below
    return res

if __name__ == "__main__":
    rows = []
    t0 = time.time()
    for pat in PATTERNS:
        for pol in POLICIES:
            for sd in SEEDS:
                rows.append(run(pol, pat, sd))
            print(f"{pat:7s} {pol:15s} done  ({time.time() - t0:.0f}s elapsed)", flush=True)
    df = pd.DataFrame(rows).drop(columns=[c for c in pd.DataFrame(rows).columns if c.startswith("share_")])
    df.to_csv("sim_runs.csv", index=False)
    cols = ["mean_T", "max_T", "viol_pct", "imbalance_C", "p50_ms", "p95_ms", "thr_rps",
            "J_per_req", "meanT_nodeA", "meanT_nodeB", "meanT_nodeC", "fc_raw_mae", "fc_cor_mae"]
    pd.set_option("display.width", 250)
    g = df.groupby(["pattern", "policy"])[cols].mean().round(2)
    print(g.to_string())
    print("\nSaved sim_runs.csv")