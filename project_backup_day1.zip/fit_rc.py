import json
import numpy as np
import pandas as pd
from scipy.optimize import least_squares

SUB = 2  # sub-steps per second for numerical stability

def sim1(x, P, T0):
    Tamb, R, C = x[0], np.exp(x[1]), np.exp(x[2])
    T = T0
    out = np.empty(len(P))
    dt = 1.0 / SUB
    for i, p in enumerate(P):
        out[i] = T
        for _ in range(SUB):
            T += dt * (p - (T - Tamb) / R) / C
    return out

def sim2(x, P, T0):
    Tamb = x[0]
    R1, C1, R2, C2 = np.exp(x[1]), np.exp(x[2]), np.exp(x[3]), np.exp(x[4])
    T1 = T0
    T2 = max(Tamb, T0 - R1 * P[0])
    out = np.empty(len(P))
    dt = 1.0 / SUB
    for i, p in enumerate(P):
        out[i] = T1
        for _ in range(SUB):
            q12 = (T1 - T2) / R1
            T1 += dt * (p - q12) / C1
            T2 += dt * (q12 - (T2 - Tamb) / R2) / C2
    return out

def segments(df, by_label):
    gap = df["timestamp"].diff().dt.total_seconds()
    new = gap.isna() | (gap > 3)
    if by_label:
        new = new | (df["workload_type"] != df["workload_type"].shift())
    seg = new.cumsum()
    out = []
    for _, g in df.groupby(seg):
        if len(g) >= 10:
            out.append((g["temperature_c"].values.astype(float), g["power_watts"].values.astype(float)))
    return out

old = pd.read_csv("gpu_telemetry.csv")
old["timestamp"] = pd.to_datetime(old["timestamp"])
old = old.reset_index(drop=True)
is_cyc = old["workload_type"] == "cycling_heavy_idle"
fb = old.index[is_cyc & (old["gpu_utilization_percent"] >= 50)].min()
old.loc[is_cyc & (old.index < fb), "workload_type"] = "idle_long"
train_segs = segments(old, True)

new = pd.read_csv("gpu_telemetry_random.csv")
new["timestamp"] = pd.to_datetime(new["timestamp"])
test_segs = segments(new.reset_index(drop=True), False)

print("Train segments:", len(train_segs), "| rows:", sum(len(t) for t, _ in train_segs))
print("Test segments:", len(test_segs), "| rows:", sum(len(t) for t, _ in test_segs))

def fit(simf, x0, lo, hi):
    def res(x):
        return np.concatenate([simf(x, P, T[0]) - T for T, P in train_segs])
    r = least_squares(res, x0, bounds=(lo, hi))
    return r.x

def free_run_err(simf, x, segs):
    e = np.concatenate([simf(x, P, T[0]) - T for T, P in segs])
    return np.abs(e).mean(), np.sqrt((e ** 2).mean()), np.abs(e).max()

def window_err(simf, x, segs, W=60):
    errs = []
    for T, P in segs:
        for s in range(0, len(T) - W, W):
            errs.append(simf(x, P[s:s + W], T[s]) - T[s:s + W])
    e = np.concatenate(errs)
    return np.abs(e).mean(), np.sqrt((e ** 2).mean()), np.abs(e).max()

print("\nFitting 1-part model ...")
x1 = fit(sim1, [25, np.log(0.08), np.log(400)], [10, np.log(0.001), np.log(1)], [40, np.log(2), np.log(1e5)])
print("Fitting 2-part model ...")
x2 = fit(sim2, [25, np.log(0.02), np.log(300), np.log(0.05), np.log(1500)],
         [10, np.log(0.001), np.log(1), np.log(0.001), np.log(1)],
         [40, np.log(2), np.log(1e5), np.log(2), np.log(1e6)])

print("\n1-part: Tamb=%.1f  R=%.4f C/W  C=%.1f J/C  tau=%.1f s" % (x1[0], np.exp(x1[1]), np.exp(x1[2]), np.exp(x1[1] + x1[2])))
print("2-part: Tamb=%.1f  R1=%.4f C1=%.1f R2=%.4f C2=%.1f" % (x2[0], np.exp(x2[1]), np.exp(x2[2]), np.exp(x2[3]), np.exp(x2[4])))

print("\n(errors in C: MAE, RMSE, max)")
for name, f, x in [("1-part", sim1, x1), ("2-part", sim2, x2)]:
    print(f"{name} TRAIN full-run   :", np.round(free_run_err(f, x, train_segs), 2))
    print(f"{name} TEST  full-run   :", np.round(free_run_err(f, x, test_segs), 2))
    print(f"{name} TEST  60s windows:", np.round(window_err(f, x, test_segs), 2))

json.dump({"model1": {"x": x1.tolist()}, "model2": {"x": x2.tolist()}}, open("rc_params.json", "w"), indent=2)
print("\nSaved rc_params.json")