import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

LAG = 5
HORIZONS = [5, 10, 30]
FEATURES = ["temperature_c", "gpu_utilization_percent", "memory_utilization_percent",
            "power_watts", "temp_lag", "temp_trend", "util_mean5", "power_mean5"]

def segments(df, by_label):
    gap = df["timestamp"].diff().dt.total_seconds()
    new = gap.isna() | (gap > 3)
    if by_label:
        new = new | (df["workload_type"] != df["workload_type"].shift())
    df["segment"] = new.cumsum()
    return df

def build(df, H):
    frames = []
    for _, g in df.groupby("segment"):
        g = g.copy()
        g["temp_lag"] = g["temperature_c"].shift(LAG)
        g["temp_trend"] = g["temperature_c"] - g["temp_lag"]
        g["util_mean5"] = g["gpu_utilization_percent"].rolling(LAG).mean()
        g["power_mean5"] = g["power_watts"].rolling(LAG).mean()
        g["future"] = g["temperature_c"].shift(-H)
        frames.append(g.dropna(subset=FEATURES + ["future"]))
    return pd.concat(frames)

# TRAIN data: old file, cleaned
old = pd.read_csv("gpu_telemetry.csv")
old["timestamp"] = pd.to_datetime(old["timestamp"])
old = old.reset_index(drop=True)
is_cyc = old["workload_type"] == "cycling_heavy_idle"
first_busy = old.index[is_cyc & (old["gpu_utilization_percent"] >= 50)].min()
old.loc[is_cyc & (old.index < first_busy), "workload_type"] = "idle_long"
old = segments(old, by_label=True)

# TEST data: new random run (never seen in training)
new = pd.read_csv("gpu_telemetry_random.csv")
new["timestamp"] = pd.to_datetime(new["timestamp"])
new = new.reset_index(drop=True)
new = segments(new, by_label=False)
print("Random run rows:", len(new), "| segments:", new["segment"].nunique())

rows, rows_all = [], []
for H in HORIZONS:
    train = build(old, H)
    test = build(new, H)
    ytr = train["future"] - train["temperature_c"]
    lin = LinearRegression().fit(train[FEATURES], ytr)
    rf = RandomForestRegressor(n_estimators=200, random_state=42, n_jobs=-1).fit(train[FEATURES], ytr)
    test = test.copy()
    test["naive"] = test["temperature_c"]
    test["linear"] = test["temperature_c"] + lin.predict(test[FEATURES])
    test["rf"] = test["temperature_c"] + rf.predict(test[FEATURES])

    def mae_row(name, t):
        return {"H": H, "subset": name, "n": len(t),
                "naive": mean_absolute_error(t["future"], t["naive"]),
                "linear": mean_absolute_error(t["future"], t["linear"]),
                "rf": mean_absolute_error(t["future"], t["rf"])}

    for ph, t in test.groupby("phase"):
        rows.append(mae_row("phase=" + ph, t))
    rows.append(mae_row("DYNAMIC (|trend|>=2)", test[test["temp_trend"].abs() >= 2]))
    rows.append(mae_row("ALL", test))

    for m in ["naive", "linear", "rf"]:
        rows_all.append({"H": H, "model": m,
                         "MAE": mean_absolute_error(test["future"], test[m]),
                         "RMSE": mean_squared_error(test["future"], test[m]) ** 0.5,
                         "R2": r2_score(test["future"], test[m])})

print("\nMAE by subset (train = old data, test = random run)")
print(pd.DataFrame(rows).round(3).to_string(index=False))
print("\nOverall metrics on random run")
print(pd.DataFrame(rows_all).round(3).to_string(index=False))
pd.DataFrame(rows).to_csv("random_eval_breakdown.csv", index=False)
pd.DataFrame(rows_all).to_csv("random_eval_overall.csv", index=False)
print("\nSaved random_eval_breakdown.csv and random_eval_overall.csv")