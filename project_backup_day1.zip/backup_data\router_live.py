import sys
import time
import threading
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pandas as pd
import requests

from emulator import load_params, Forecaster

PARAMS = load_params("2-part+fan")
URL = ["http://127.0.0.1:8011", "http://127.0.0.1:8012", "http://127.0.0.1:8013"]
N = 3
WQ = 20.0                     # frozen from the simulator test
HP = 10                       # forecast horizon, emulated seconds (= 1 poll at accel 10)
ALPHA_LIVE = 1 - 0.9 ** 10    # sim ALPHA 0.1 per emulated second, converted to one 10 s poll
WARM_REAL = 20.0              # real seconds ignored (= 200 emulated s, as in the simulator)
T_SOFT = 70.0
RATES = {"steady": 15.0, "moderate": 10.0}   # requests per REAL second
POLICIES_ALL = ["round_robin", "least_load", "reactive", "predictive"]
TCRIT = {1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262}

tl = threading.local()


def session():
    s = getattr(tl, "s", None)
    if s is None:
        s = requests.Session()
        tl.s = s
    return s


def run_one(policy, pattern, seed, dur):
    for u in URL:
        requests.post(u + "/reset", timeout=10)
    time.sleep(1.5)

    rng = np.random.default_rng(seed)
    arrivals = []
    for s in range(dur):
        n = rng.poisson(RATES[pattern])
        arrivals += list(s + np.sort(rng.random(n)))

    lock = threading.Lock()
    stop = threading.Event()
    ready = threading.Event()
    hist = []
    sig = np.zeros(N)
    inflight = [0] * N
    rrc = [0]
    results = []
    fcs = [Forecaster(PARAMS) for _ in range(N)]
    p_ewma = np.full(N, 30.0)
    bias = np.zeros(N)
    raw_prev = [None] * N
    cur_reads = np.full(N, 30.0)
    cur_pow = np.full(N, 30.0)

    def poller():
        k = 0
        last = None
        accel = 10
        base = time.perf_counter()
        while not stop.is_set():
            now = time.perf_counter()
            for i in range(N):
                try:
                    tel = requests.get(URL[i] + "/telemetry", timeout=2).json()
                    cur_reads[i] = tel["temp_c"]
                    cur_pow[i] = tel["power_est_w"]
                    accel = tel.get("accel", accel)
                except Exception:
                    pass
            new_sig = cur_reads.copy()
            if policy.startswith("predictive"):
                steps = 0 if last is None else max(1, int(round((now - last) * accel)))
                for i in range(N):
                    for _ in range(steps):
                        fcs[i].advance(cur_pow[i], 1.0)
                    fcs[i].observe(cur_reads[i], cur_pow[i])
                    p_ewma[i] = 0.7 * p_ewma[i] + 0.3 * cur_pow[i]
                    if raw_prev[i] is not None:
                        bias[i] = (1 - ALPHA_LIVE) * bias[i] + ALPHA_LIVE * (cur_reads[i] - raw_prev[i])
                    raw = fcs[i].predict(HP, [p_ewma[i]] * HP)
                    raw_prev[i] = raw
                    new_sig[i] = raw + bias[i]
            last = now
            with lock:
                sig[:] = new_sig
            hist.append((now, cur_reads.copy(), cur_pow.copy()))
            ready.set()
            k += 1
            stop.wait(max(0.0, base + k * 1.0 - time.perf_counter()))

    pth = threading.Thread(target=poller, daemon=True)
    pth.start()
    ready.wait(10)
    t0 = time.perf_counter() + 0.5

    def choose():
        with lock:
            q = np.array(inflight, float)
            if policy == "round_robin":
                i = rrc[0] % N
            elif policy == "least_load":
                i = min(range(N), key=lambda j: (q[j], (j - rrc[0]) % N))
            else:
                i = int(np.argmin(sig + WQ * q))
            rrc[0] += 1
            inflight[i] += 1
        return i

    def task(i, sched):
        ok = False
        try:
            r = session().post(URL[i] + "/infer", timeout=120)
            ok = r.status_code == 200
        except Exception:
            pass
        done = time.perf_counter()
        with lock:
            inflight[i] -= 1
            results.append((i, sched - t0, (done - sched) * 1000.0, ok))

    ex = ThreadPoolExecutor(max_workers=128)
    for a in arrivals:
        target = t0 + a
        d = target - time.perf_counter()
        if d > 0:
            time.sleep(d)
        i = choose()
        ex.submit(task, i, target)
    ex.shutdown(wait=True)
    stop.set()
    pth.join(5)

    H = [h for h in hist if WARM_REAL <= h[0] - t0 <= dur]
    T = np.array([h[1] for h in H])
    flat = T.ravel()
    good = [r for r in results if r[3]]
    res = [r for r in good if r[1] >= WARM_REAL]
    lat = np.array([r[2] for r in res])
    share = np.bincount([r[0] for r in results], minlength=N) / max(1, len(results))
    return dict(policy=policy, pattern=pattern, seed=seed,
                mean_T=flat.mean(), p99_T=np.percentile(flat, 99), max_T=flat.max(),
                imbalance_C=(T.max(axis=1) - T.min(axis=1)).mean(),
                viol_pct=100 * (flat > T_SOFT).mean(),
                p50_ms=np.percentile(lat, 50), p95_ms=np.percentile(lat, 95),
                p99_ms=np.percentile(lat, 99), thr_rps=len(good) / dur,
                errors=len(results) - len(good), polls=len(H),
                share_A=share[0], share_B=share[1], share_C=share[2])


if __name__ == "__main__":
    pattern = sys.argv[1]
    first_seed = int(sys.argv[2])
    n_seeds = int(sys.argv[3])
    dur = int(sys.argv[4])
    pols = sys.argv[5].split(",") if len(sys.argv) > 5 else POLICIES_ALL

    for u in URL:
        print(requests.get(u + "/health", timeout=5).json())

    rows = []
    for sd in range(first_seed, first_seed + n_seeds):
        for pol in pols:
            print("running", pol, pattern, sd, flush=True)
            r = run_one(pol, pattern, sd, dur)
            rows.append(r)
            print("   p99_T %.1f  max_T %.1f  imb %.2f  p95 %.0f ms  thr %.2f  errors %d  share %.2f/%.2f/%.2f"
                  % (r["p99_T"], r["max_T"], r["imbalance_C"], r["p95_ms"], r["thr_rps"],
                     r["errors"], r["share_A"], r["share_B"], r["share_C"]), flush=True)

    df = pd.DataFrame(rows)
    df.to_csv("live_runs_%s_%d.csv" % (pattern, first_seed), index=False)
    cols = ["mean_T", "p99_T", "max_T", "imbalance_C", "viol_pct", "p50_ms", "p95_ms", "thr_rps"]
    print("\n=== mean over seeds ===")
    print(df.groupby("policy")[cols].mean().round(2).to_string())
    if n_seeds >= 2:
        print("\n=== paired differences (same seeds), negative = A lower ===")
        for a, b in [("predictive", "least_load"), ("reactive", "least_load"), ("predictive", "reactive")]:
            if a in pols and b in pols:
                pa = df[df.policy == a].set_index("seed")
                pb = df[df.policy == b].set_index("seed")
                parts = []
                for m in ["p99_T", "max_T", "imbalance_C", "p95_ms"]:
                    d = (pa[m] - pb[m]).values
                    ci = TCRIT.get(len(d) - 1, 2.0) * d.std(ddof=1) / np.sqrt(len(d))
                    parts.append("%s=%+.2f+/-%.2f" % (m, d.mean(), ci))
                print(a, "-", b, ":", "  ".join(parts))
    print("\nSaved live_runs_%s_%d.csv" % (pattern, first_seed))