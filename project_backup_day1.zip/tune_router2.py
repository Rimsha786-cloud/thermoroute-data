import pandas as pd
import sim_router as S

SEEDS = range(100, 105)
PATS = ["steady", "bursty", "moderate", "high"]
configs = []
for wq in [3, 8, 20]:
    configs.append(("hard_off", wq, 999, 0))
for wq in [3, 8]:
    for g in [66, 70]:
        for ws in [1, 3]:
            configs.append(("soft", wq, g, ws))

rows = []
for pat in PATS:
    for sd in SEEDS:
        r = S.run("least_load", pat, sd)
        r.update(mode="least_load", WQ=0, guard=0, WSOFT=0)
        rows.append(r)
    for mode, wq, g, ws in configs:
        S.GUARD_MODE = "soft" if mode == "soft" else "hard"
        S.WQ, S.T_GUARD, S.WSOFT = wq, g, ws
        for sd in SEEDS:
            r = S.run("predictive", pat, sd)
            r.update(mode=mode, WQ=wq, guard=g, WSOFT=ws)
            rows.append(r)
    print(pat, "done", flush=True)

df = pd.DataFrame(rows)
df.to_csv("tune_runs2.csv", index=False)
cols = ["p99_T", "max_T", "imbalance_C", "p50_ms", "p95_ms", "thr_rps"]
pd.set_option("display.width", 250)
pd.set_option("display.max_rows", 200)
print(df.groupby(["pattern", "mode", "WQ", "guard", "WSOFT"])[cols].mean().round(2).to_string())