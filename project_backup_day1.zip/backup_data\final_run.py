import numpy as np
import pandas as pd
import sim_router as S

S.WQ = 20
S.T_GUARD = 999
S.GUARD_MODE = "hard"

POLS = ["round_robin", "least_load", "reactive", "predictive_raw", "predictive"]
PATS = ["steady", "bursty", "moderate", "high"]
SEEDS = range(10)
TCRIT = 2.262  # t value, 95%, 9 degrees of freedom

rows = []
for pat in PATS:
    for pol in POLS:
        for sd in SEEDS:
            rows.append(S.run(pol, pat, sd))
    print(pat, "done", flush=True)

df = pd.DataFrame(rows)
df = df[[c for c in df.columns if not c.startswith("share_")]]
df.to_csv("final_runs.csv", index=False)

def ci(x):
    x = np.asarray(x, float)
    return TCRIT * x.std(ddof=1) / np.sqrt(len(x))

M = ["p99_T", "max_T", "imbalance_C", "viol_pct", "throttle_pct",
     "p50_ms", "p95_ms", "thr_rps", "J_per_req"]
pd.set_option("display.width", 250)

print("\n=== mean +/- 95% CI over 10 seeds ===")
for pat in PATS:
    print("\n" + pat)
    out = []
    for pol in POLS:
        d = df[(df.pattern == pat) & (df.policy == pol)]
        row = {"policy": pol}
        for m in M:
            row[m] = f"{d[m].mean():.2f}+/-{ci(d[m]):.2f}"
        out.append(row)
    print(pd.DataFrame(out).to_string(index=False))

PAIRS = [("predictive", "least_load"), ("reactive", "least_load"),
         ("predictive", "reactive"), ("predictive", "predictive_raw")]
PM = ["p99_T", "max_T", "imbalance_C", "p95_ms", "J_per_req"]

print("\n=== paired differences A minus B (same seeds), negative = A lower ===")
for pat in PATS:
    print("\n" + pat)
    out = []
    for a, b in PAIRS:
        da = df[(df.pattern == pat) & (df.policy == a)].sort_values("seed")
        db = df[(df.pattern == pat) & (df.policy == b)].sort_values("seed")
        row = {"A - B": a + " - " + b}
        for m in PM:
            diff = da[m].values - db[m].values
            row[m] = f"{diff.mean():+.2f}+/-{ci(diff):.2f}"
        out.append(row)
    print(pd.DataFrame(out).to_string(index=False))

print("\nSaved final_runs.csv")