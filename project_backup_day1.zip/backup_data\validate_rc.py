import numpy as np
import pandas as pd
from emulator import load_params, NodeThermal, Forecaster

FILES = [
    ("home_random1 (used to choose model, not clean)", "gpu_telemetry_random.csv"),
    ("home_random2 (held-out)", "gpu_telemetry_random2.csv"),
    ("lab_1 (second card)", "gpu_telemetry_lab.csv"),
    ("lab_2 (second card)", "gpu_telemetry_lab2.csv"),
]
PARAMS = load_params("2-part+fan")
ALPHA = 0.1
HS = (10, 30)
W = 60
STEP = 10
MINSEG = 70
WARM = 40


def load_segments(fn):
    d = pd.read_csv(fn)
    ts = pd.to_datetime(d["timestamp"])
    gap = ts.diff().dt.total_seconds().fillna(1).values
    seg_id = np.cumsum(gap > 3)
    segs = []
    for s in np.unique(seg_id):
        m = seg_id == s
        T = d.loc[m, "temperature_c"].astype(float).values
        P = d.loc[m, "power_watts"].astype(float).values
        if len(T) >= MINSEG:
            segs.append((T, P))
    return segs


def window_test(T, P):
    out = []
    for s in range(0, len(T) - W, STEP):
        n = NodeThermal(PARAMS, noise_sd=0.0)
        n.T1 = T[s]
        n.T2 = max(n.Tamb, T[s] - n.R1 * P[s])
        for j in range(W):
            n.step(1.0, P[s + j])
            out.append(n.T1 - T[s + j + 1])
    return out


def forecast_test(T, P):
    rows = []
    f = Forecaster(PARAMS)
    bias = {H: 0.0 for H in HS}
    hist = {H: {} for H in HS}
    for t in range(len(T)):
        f.observe(T[t], P[t])
        for H in HS:
            if (t - H) in hist[H]:
                e = T[t] - hist[H][t - H]
                bias[H] = (1 - ALPHA) * bias[H] + ALPHA * e
            if t + H < len(T):
                raw = f.predict(H, P[t:t + H])
                hist[H][t] = raw
                if t >= WARM:
                    truth = T[t + H]
                    rows.append(dict(H=H,
                                     naive=abs(T[t] - truth),
                                     raw=abs(raw - truth),
                                     bc=abs(raw + bias[H] - truth),
                                     raw_signed=raw - truth,
                                     dyn=abs(T[t] - T[t - 5]) >= 2))
        f.advance(P[t])
    return rows


win_rows = []
fc_rows = []
for label, fn in FILES:
    segs = load_segments(fn)
    print(label, fn, "usable segments:", [len(s[0]) for s in segs])
    errs = []
    fr = []
    for T, P in segs:
        errs += window_test(T, P)
        fr += forecast_test(T, P)
    e = np.array(errs)
    win_rows.append(dict(file=label, n=len(e),
                         MAE=np.abs(e).mean(), RMSE=np.sqrt((e ** 2).mean()),
                         bias=e.mean(), maxabs=np.abs(e).max()))
    d = pd.DataFrame(fr)
    for H in HS:
        for sub in ("ALL", "DYN"):
            x = d[d.H == H]
            if sub == "DYN":
                x = x[x.dyn]
            fc_rows.append(dict(file=label, H=H, rows=sub, n=len(x),
                                naive=x.naive.mean(), raw=x.raw.mean(),
                                biascorr=x.bc.mean(),
                                raw_bias=x.raw_signed.mean()))

pd.set_option("display.width", 250)
wdf = pd.DataFrame(win_rows).round(2)
fdf = pd.DataFrame(fc_rows).round(2)
print("\n=== 60 s free-run window error (C), measured power, frozen params ===")
print(wdf.to_string(index=False))
print("\n=== Forecast MAE (C), TRUE future power given (oracle), frozen params ===")
print(fdf.to_string(index=False))
wdf.to_csv("validate_window.csv", index=False)
fdf.to_csv("validate_forecast.csv", index=False)
print("\nSaved validate_window.csv and validate_forecast.csv")