import os
import time
import csv
from datetime import datetime

os.add_dll_directory(r"C:\Windows\System32")

import pynvml

# Start NVIDIA monitoring
pynvml.nvmlInit()

handle = pynvml.nvmlDeviceGetHandleByIndex(0)
workload_type = input("Enter workload type: ")
# Create/open our dataset
with open("gpu_telemetry.csv", "a", newline="") as file:

    writer = csv.writer(file)

    # Add column names if the file is empty
    if file.tell() == 0:
        writer.writerow([
            "timestamp",
            "workload_type",
            "temperature_c",
            "gpu_utilization_percent",
            "memory_utilization_percent",
            "power_watts"
        ])

    print("Data collection started.")
    print("Press Ctrl + C to stop.\n")

    try:
        while True:

            timestamp = datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            )

            temperature = pynvml.nvmlDeviceGetTemperature(
                handle,
                pynvml.NVML_TEMPERATURE_GPU
            )

            utilization = pynvml.nvmlDeviceGetUtilizationRates(
                handle
            )

            power = pynvml.nvmlDeviceGetPowerUsage(
                handle
            ) / 1000

            writer.writerow([
                timestamp,
                workload_type,
                temperature,
                utilization.gpu,
                utilization.memory,
                round(power, 2)
            ])

            # Make sure the data is immediately saved
            file.flush()

            print(
                f"{timestamp} | "
                f"Temp: {temperature}°C | "
                f"GPU: {utilization.gpu}% | "
                f"Memory: {utilization.memory}% | "
                f"Power: {power:.2f} W"
            )

            time.sleep(1)

    except KeyboardInterrupt:
        print("\nData collection stopped.")

pynvml.nvmlShutdown()