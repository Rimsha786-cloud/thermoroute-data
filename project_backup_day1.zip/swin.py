import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import timm
from tqdm import tqdm
import matplotlib.pyplot as plt

# Device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using:", device)

# Hyperparameters
IMG_SIZE = 224
BATCH_SIZE = 32
EPOCHS = 50
LR = 1e-4

# Data augmentation
train_transform = transforms.Compose([
   transforms.Resize((IMG_SIZE, IMG_SIZE)),
   transforms.RandomHorizontalFlip(),
   transforms.RandomRotation(15),
   transforms.ColorJitter(brightness=0.2),
   transforms.ToTensor(),
   transforms.Normalize([0.485,0.456,0.406],
                        [0.229,0.224,0.225])
])

test_transform = transforms.Compose([
   transforms.Resize((IMG_SIZE, IMG_SIZE)),
   transforms.ToTensor(),
   transforms.Normalize([0.485,0.456,0.406],
                        [0.229,0.224,0.225])
])

# Dataset paths
train_dir = "Rice_Dataset/train"
val_dir = "Rice_Dataset/val"
test_dir = "Rice_Dataset/test"

train_dataset = datasets.ImageFolder(train_dir, train_transform)
val_dataset = datasets.ImageFolder(val_dir, test_transform)
test_dataset = datasets.ImageFolder(test_dir, test_transform)

train_loader = DataLoader(train_dataset,
                         batch_size=BATCH_SIZE,
                         shuffle=True)

val_loader = DataLoader(val_dataset,
                       batch_size=BATCH_SIZE,
                       shuffle=False)

test_loader = DataLoader(test_dataset,
                        batch_size=BATCH_SIZE,
                        shuffle=False)

classes = train_dataset.classes
num_classes = len(classes)

print("Classes:", classes)

# Swin Transformer Model
model = timm.create_model(
   'swin_tiny_patch4_window7_224',
   pretrained=True,
   num_classes=num_classes
)

model = model.to(device)

criterion = nn.CrossEntropyLoss()
optimizer = optim.AdamW(model.parameters(), lr=LR)

train_losses = []
val_losses = []

train_accs = []
val_accs = []

best_acc = 0

for epoch in range(EPOCHS):

   model.train()

   running_loss = 0
   correct = 0
   total = 0

   for images, labels in tqdm(train_loader):

       images = images.to(device)
       labels = labels.to(device)

       optimizer.zero_grad()

       outputs = model(images)

       loss = criterion(outputs, labels)

       loss.backward()

       optimizer.step()

       running_loss += loss.item()

       _, predicted = outputs.max(1)

       total += labels.size(0)

       correct += predicted.eq(labels).sum().item()

   train_loss = running_loss / len(train_loader)
   train_acc = 100 * correct / total

   train_losses.append(train_loss)
   train_accs.append(train_acc)

   # Validation
   model.eval()

   val_loss = 0
   correct = 0
   total = 0

   with torch.no_grad():

       for images, labels in val_loader:

           images = images.to(device)
           labels = labels.to(device)

           outputs = model(images)

           loss = criterion(outputs, labels)

           val_loss += loss.item()

           _, predicted = outputs.max(1)

           total += labels.size(0)

           correct += predicted.eq(labels).sum().item()

   val_loss /= len(val_loader)
   val_acc = 100 * correct / total

   val_losses.append(val_loss)
   val_accs.append(val_acc)

   print(f"\nEpoch [{epoch+1}/{EPOCHS}]")
   print(f"Train Loss: {train_loss:.4f}")
   print(f"Train Acc : {train_acc:.2f}%")
   print(f"Val Loss  : {val_loss:.4f}")
   print(f"Val Acc   : {val_acc:.2f}%")

   if val_acc > best_acc:
       best_acc = val_acc
       torch.save(model.state_dict(),
                  "best_swin_rice_model.pth")

print("Training Complete")

4. Testing & Metrics
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
import seaborn as sns
import numpy as np

model.load_state_dict(
   torch.load("best_swin_rice_model.pth")
)

model.eval()

all_preds = []
all_labels = []

with torch.no_grad():

   for images, labels in test_loader:

       images = images.to(device)

       outputs = model(images)

       _, preds = torch.max(outputs,1)

       all_preds.extend(preds.cpu().numpy())
       all_labels.extend(labels.numpy())

print(classification_report(
   all_labels,
   all_preds,
   target_names=classes
))

5. Confusion Matrix
cm = confusion_matrix(all_labels, all_preds)

plt.figure(figsize=(8,6))

sns.heatmap(
   cm,
   annot=True,
   fmt='d',
   cmap='Blues',
   xticklabels=classes,
   yticklabels=classes
)

plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")

plt.savefig("confusion_matrix.png")
plt.show()

6. Accuracy Graph
plt.figure(figsize=(8,5))

plt.plot(train_accs,label='Train Accuracy')
plt.plot(val_accs,label='Validation Accuracy')

plt.xlabel("Epoch")
plt.ylabel("Accuracy (%)")
plt.title("Training Accuracy")

plt.legend()

plt.savefig("accuracy_graph.png")

plt.show()

7. Loss Graph
plt.figure(figsize=(8,5))

plt.plot(train_losses,label='Train Loss')
plt.plot(val_losses,label='Validation Loss')

plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.title("Training Loss")

plt.legend()

plt.savefig("loss_graph.png")

plt.show()
