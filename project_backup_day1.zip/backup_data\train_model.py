import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib

df = pd.read_csv("gpu_prediction_dataset.csv")
df["timestamp"] = pd.to_datetime(df["timestamp"])

df_encoded = pd.get_dummies(df, columns=["workload_type"])

feature_cols = [c for c in df_encoded.columns if c not in
                ["timestamp", "future_temperature_c"]]

# Chronological split PER workload run, not random shuffling
train_frames, test_frames = [], []
for workload, group in df.groupby("workload_type"):
    group = group.sort_values("timestamp").reset_index(drop=True)
    split_idx = int(len(group) * 0.8)
    train_frames.append(group.iloc[:split_idx])
    test_frames.append(group.iloc[split_idx:])

train_df = pd.concat(train_frames, ignore_index=True)
test_df = pd.concat(test_frames, ignore_index=True)

train_df = pd.get_dummies(train_df, columns=["workload_type"])
test_df = pd.get_dummies(test_df, columns=["workload_type"])

# Align columns in case a workload type is missing from either split
train_df, test_df = train_df.align(test_df, join="left", axis=1, fill_value=0)

X_train = train_df[feature_cols]
y_train = train_df["future_temperature_c"]
X_test = test_df[feature_cols]
y_test = test_df["future_temperature_c"]

model = RandomForestRegressor(n_estimators=200, random_state=42)
model.fit(X_train, y_train)

preds = model.predict(X_test)

mae = mean_absolute_error(y_test, preds)
rmse = mean_squared_error(y_test, preds) ** 0.5
r2 = r2_score(y_test, preds)

print("MAE:", mae)
print("RMSE:", rmse)
print("R2:", r2)

importances = pd.Series(model.feature_importances_, index=feature_cols)
print("\nFeature importances:")
print(importances.sort_values(ascending=False))

joblib.dump(model, "temp_predictor_rf.pkl")
print("\nModel saved as temp_predictor_rf.pkl")
# Naive baseline: assume future temperature = current temperature
naive_preds = test_df["temperature_c"]

naive_mae = mean_absolute_error(y_test, naive_preds)
naive_rmse = mean_squared_error(y_test, naive_preds) ** 0.5
naive_r2 = r2_score(y_test, naive_preds)

print("\n--- Naive persistence baseline ---")
print("Naive MAE:", naive_mae)
print("Naive RMSE:", naive_rmse)
print("Naive R2:", naive_r2)