﻿import requests
import itertools
import time
import json

NODES = [
    "http://127.0.0.1:8001",
    "http://127.0.0.1:8002",
    "http://127.0.0.1:8003",
]

node_cycle = itertools.cycle(NODES)

def route_request():
    node = next(node_cycle)
    start = time.time()
    resp = requests.post(f"{node}/infer")
    latency = (time.time() - start) * 1000
    return {"node": node, "latency_ms": round(latency, 2), "response": resp.json()}

if __name__ == "__main__":
    NUM_REQUESTS = 60
    results = []
    for i in range(NUM_REQUESTS):
        result = route_request()
        results.append(result)
        print(f"Request {i+1}: routed to {result['node']} -> latency {result['latency_ms']}ms")

    with open("baseline_results.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nSaved results to baseline_results.json")
