﻿import torch
import time

device = torch.device("cuda")
print("GPU:", torch.cuda.get_device_name(0), flush=True)
print("Starting CYCLING workload (idle <-> heavy)...", flush=True)

size = 8192
a = torch.randn((size, size), device=device, dtype=torch.float16)
b = torch.randn((size, size), device=device, dtype=torch.float16)

HEAVY_SECONDS = 40
IDLE_SECONDS = 40

while True:
    print("Phase: HEAVY", flush=True)
    start = time.time()
    while time.time() - start < HEAVY_SECONDS:
        c = torch.matmul(a, b)
        torch.cuda.synchronize()

    print("Phase: IDLE (cooling)", flush=True)
    time.sleep(IDLE_SECONDS)
