import numpy as np
import pandas as pd
from emulator import (load_params, build_power_table, NodeThermal, Forecaster, CONFIGS)

params = load_params()
ux, py = build_power_table()
pw = lambda u: float(np.interp(u, ux, py))

rng = np.random.default_rng(321)
lv = []
while len(lv) < 1200:
    lvl = rng.choice([100.0, 21.0, 0.0], p=[0.45, 0.2, 0.35])
    lv += [lvl] * int(rng.integers(10, 61))
P = np.array([pw(u) for u in lv[:1200]])

HS = (10, 30)
ALPHA = 0.1
rows = []
for i_n, (k, cfg) in enumerate(CONFIGS.items()):
    plant = NodeThermal(params, seed=100 + i_n, **cfg)
    fc = Forecaster(params)
    Tm = []
    raw = {H: [] for H in HS}
    cor = {H: [] for H in HS}
    bias = {H: 0.0 for H in HS}
    for i in range(len(P)):
        r = plant.read_temp()
        Tm.append(r)
        fc.observe(r, P[i])
        for H in HS:
            if i >= H:
                bias[H] = (1 - ALPHA) * bias[H] + ALPHA * (r - raw[H][i - H])
            p = fc.predict(H, P[i:i + H])
            raw[H].append(p)
            cor[H].append(p + bias[H])
        plant.step(1.0, P[i])
        fc.advance(P[i])
    Tm = np.array(Tm, dtype=float)
    for H in HS:
        idx = np.arange(30, len(P) - H)
        true = Tm[idx + H]
        naive = Tm[idx]
        rawp = np.array(raw[H])[idx]
        corp = np.array(cor[H])[idx]
        dyn = np.abs(Tm[idx] - Tm[idx - 5]) >= 2
        rows.append({"node": k, "H": H,
                     "DYN_naive": np.abs(naive - true)[dyn].mean(),
                     "DYN_raw": np.abs(rawp - true)[dyn].mean(),
                     "DYN_biascorr": np.abs(corp - true)[dyn].mean(),
                     "ALL_naive": np.abs(naive - true).mean(),
                     "ALL_raw": np.abs(rawp - true).mean(),
                     "ALL_biascorr": np.abs(corp - true).mean()})
res = pd.DataFrame(rows).round(2)
print(res.to_string(index=False))
res.to_csv("forecast_test2.csv", index=False)