import pandas as pd

HORIZON_SECONDS = 10
LAG_SECONDS = 5  # how far back to look for trend

df = pd.read_csv("gpu_telemetry.csv")
df["timestamp"] = pd.to_datetime(df["timestamp"])

frames = []
for workload, group in df.groupby("workload_type"):
    group = group.reset_index(drop=True)

    # Lag feature: temperature N seconds ago
    group["temp_lag"] = group["temperature_c"].shift(LAG_SECONDS)
    # Trend feature: rate of change over the lag window
    group["temp_trend"] = group["temperature_c"] - group["temp_lag"]

    # Target: future temperature
    group["future_temperature_c"] = group["temperature_c"].shift(-HORIZON_SECONDS)

    frames.append(group)

result = pd.concat(frames, ignore_index=True)
result = result.dropna(subset=["future_temperature_c", "temp_lag", "temp_trend"])

result.to_csv("gpu_prediction_dataset.csv", index=False)

print("Saved gpu_prediction_dataset.csv")
print("Total rows:", len(result))
print(result[["temperature_c", "temp_lag", "temp_trend", "future_temperature_c"]].head(10))