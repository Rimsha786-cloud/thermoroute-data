import argparse
import os
import threading
import time

os.add_dll_directory(r"C:\Windows\System32")

import pynvml
import torch
from fastapi import FastAPI
import uvicorn

from emulator import load_params, NodeThermal

parser = argparse.ArgumentParser()
parser.add_argument("--port", type=int, required=True)
parser.add_argument("--node-id", type=str, required=True)
parser.add_argument("--cool-scale", type=float, required=True)
parser.add_argument("--amb-offset", type=float, required=True)
parser.add_argument("--seed", type=int, default=1)
parser.add_argument("--accel", type=int, default=10)
parser.add_argument("--reps", type=int, default=3)
args = parser.parse_args()

P_IDLE = 30.0
P_MAX = 575.0
S0 = 0.153
THROTTLE_T, THROTTLE_X = 80.0, 1.25

pynvml.nvmlInit()
handle = pynvml.nvmlDeviceGetHandleByIndex(0)

device = torch.device("cuda")
SIZE = 8192
a = torch.randn((SIZE, SIZE), device=device, dtype=torch.float16)
b = torch.randn((SIZE, SIZE), device=device, dtype=torch.float16)

PARAMS = load_params("2-part+fan")
thermal = NodeThermal(PARAMS, cool_scale=args.cool_scale, amb_offset=args.amb_offset,
                      noise_sd=0.3, seed=args.seed, t_init=30.0)

counter_lock = threading.Lock()
snap_lock = threading.Lock()
infer_lock = threading.Lock()

busy_seconds = 0.0
served = 0
waiting = 0
active = 0
last_step = time.time()

snapshot = {"node_id": args.node_id, "temp_c": float(thermal.T1), "power_est_w": P_IDLE,
            "queue": 0, "busy": 0, "served": 0, "accel": args.accel,
            "real_gpu_temp_c": None, "real_gpu_power_w": None}


def telemetry_loop():
    global busy_seconds, last_step
    while True:
        time.sleep(1.0)
        now = time.time()
        dt = max(0.1, now - last_step)
        last_step = now
        with counter_lock:
            bsec = busy_seconds
            busy_seconds = 0.0
            q = waiting
            act = active
            s = served
        busy_frac = min(1.0, bsec / dt)
        power_est = P_IDLE + busy_frac * (P_MAX - P_IDLE)
        for _ in range(max(1, int(round(dt * args.accel)))):
            thermal.step(1.0, power_est)
        temp_c = float(thermal.read_temp())
        try:
            real_temp = int(pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU))
            real_power = float(pynvml.nvmlDeviceGetPowerUsage(handle) / 1000.0)
        except Exception:
            real_temp, real_power = None, None
        with snap_lock:
            snapshot.update({"temp_c": temp_c, "power_est_w": round(float(power_est), 2),
                             "queue": int(q + act), "busy": int(act), "served": int(s),
                             "real_gpu_temp_c": real_temp, "real_gpu_power_w": real_power})


app = FastAPI()


@app.get("/health")
def health():
    return {"node_id": args.node_id, "status": "ok", "accel": args.accel}


@app.get("/telemetry")
def telemetry():
    with snap_lock:
        return dict(snapshot)


@app.post("/infer")
def infer():
    global busy_seconds, served, waiting, active
    with counter_lock:
        waiting += 1
    with infer_lock:
        with counter_lock:
            waiting -= 1
            active = 1
        start = time.time()
        real_ms = 0.0
        try:
            for _ in range(args.reps):
                c = torch.matmul(a, b)
            torch.cuda.synchronize()
            real_ms = (time.time() - start) * 1000
            svc = S0 * (THROTTLE_X if thermal.T1 >= THROTTLE_T else 1.0)
            rest = svc - (time.time() - start)
            if rest > 0:
                time.sleep(rest)
        finally:
            elapsed = time.time() - start
            with counter_lock:
                busy_seconds += elapsed
                served += 1
                active = 0
    return {"node_id": args.node_id, "status": "completed",
            "service_ms": round(elapsed * 1000, 2), "real_gpu_ms": round(real_ms, 2)}
@app.post("/reset")
def reset():
    global busy_seconds, served, last_step
    with counter_lock:
        busy_seconds = 0.0
        served = 0
        last_step = time.time()
    thermal.T1 = 30.0 + args.amb_offset
    thermal.T2 = thermal.T1 - thermal.R1 * 25.0
    with snap_lock:
        snapshot.update({"temp_c": float(thermal.T1), "power_est_w": P_IDLE,
                         "queue": 0, "busy": 0, "served": 0})
    return {"node_id": args.node_id, "status": "reset", "temp_c": float(thermal.T1)}


if __name__ == "__main__":
    threading.Thread(target=telemetry_loop, daemon=True).start()
    uvicorn.run(app, host="127.0.0.1", port=args.port)