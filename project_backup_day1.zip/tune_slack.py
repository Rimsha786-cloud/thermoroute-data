import pandas as pd
import sim_router as S

SEEDS = range(100, 105)
SLACKS = [0.25, 0.5, 1, 2, 3]
rows = []
for pat in S.PATTERNS:
    for pol in ["least_load", "round_robin"]:
        for sd in SEEDS:
            r = S.run(pol, pat, sd); r["slack"] = 0; rows.append(r)
    for sl in SLACKS:
        S.SLACK = sl
        for pol in ["reactive_slack", "predictive_slack"]:
            for sd in SEEDS:
                r = S.run(pol, pat, sd); r["slack"] = sl; rows.append(r)
    print(pat, "done", flush=True)

df = pd.DataFrame(rows)
df.to_csv("tune_slack_runs.csv", index=False)
cols = ["max_T", "viol_pct", "imbalance_C", "p50_ms", "p95_ms", "meanT_nodeC", "fc_cor_mae"]
pd.set_option("display.width", 250); pd.set_option("display.max_rows", 200)
g = df.groupby(["pattern", "policy", "slack"])[cols].mean().round(2)
print(g.to_string())

ll = df[df.policy == "least_load"].groupby("pattern")[["max_T", "p95_ms"]].mean()
print("\n=== Selection rule: p95 <= 1.5x least_load in steady AND bursty; then lowest max_T ===")
out = []
for (pol, sl), sub in df[df.policy.str.endswith("_slack")].groupby(["policy", "slack"]):
    m = sub.groupby("pattern")[["max_T", "p95_ms"]].mean()
    feas = all(m.loc[p, "p95_ms"] <= 1.5 * ll.loc[p, "p95_ms"] for p in ["steady", "bursty"])
    out.append(dict(policy=pol, slack=sl, feasible=feas,
                    dmaxT_steady=m.loc["steady", "max_T"] - ll.loc["steady", "max_T"],
                    dmaxT_bursty=m.loc["bursty", "max_T"] - ll.loc["bursty", "max_T"],
                    dmaxT_high=m.loc["high", "max_T"] - ll.loc["high", "max_T"],
                    p95x_steady=m.loc["steady", "p95_ms"] / ll.loc["steady", "p95_ms"],
                    p95x_bursty=m.loc["bursty", "p95_ms"] / ll.loc["bursty", "p95_ms"]))
print(pd.DataFrame(out).round(2).to_string(index=False))