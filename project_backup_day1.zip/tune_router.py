import pandas as pd
import sim_router as S

WQS = [1.5, 3, 5, 8, 12, 20]
GUARDS = [66, 68, 70, 72]
SEEDS = range(100, 105)

rows = []
for pat in S.PATTERNS:
    for sd in SEEDS:
        r = S.run("least_load", pat, sd)
        r["WQ"] = 0
        r["guard"] = 0
        rows.append(r)
    for wq in WQS:
        for g in GUARDS:
            S.WQ = wq
            S.T_GUARD = g
            for sd in SEEDS:
                r = S.run("predictive", pat, sd)
                r["WQ"] = wq
                r["guard"] = g
                rows.append(r)
    print(pat, "done", flush=True)

df = pd.DataFrame(rows)
df.to_csv("tune_runs.csv", index=False)
cols = ["max_T", "viol_pct", "imbalance_C", "p50_ms", "p95_ms", "thr_rps", "fc_cor_mae"]
pd.set_option("display.width", 250)
pd.set_option("display.max_rows", 200)
print(df.groupby(["pattern", "policy", "WQ", "guard"])[cols].mean().round(2).to_string())