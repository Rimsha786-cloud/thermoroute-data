import os
import time

os.add_dll_directory(r"C:\Windows\System32")

import pynvml

# Start NVIDIA monitoring
pynvml.nvmlInit()

# Get GPU
handle = pynvml.nvmlDeviceGetHandleByIndex(0)

print("GPU monitoring started.")
print("Press Ctrl + C to stop.\n")

try:
    while True:

        # GPU name
        name = pynvml.nvmlDeviceGetName(handle)

        # Temperature
        temperature = pynvml.nvmlDeviceGetTemperature(
            handle,
            pynvml.NVML_TEMPERATURE_GPU
        )

        # Utilization
        utilization = pynvml.nvmlDeviceGetUtilizationRates(handle)

        # Power
        power = pynvml.nvmlDeviceGetPowerUsage(handle) / 1000

        print(
            f"GPU: {name} | "
            f"Temp: {temperature}°C | "
            f"GPU: {utilization.gpu}% | "
            f"Memory: {utilization.memory}% | "
            f"Power: {power:.2f} W"
        )

        # Wait 1 second
        time.sleep(1)

except KeyboardInterrupt:
    print("\nMonitoring stopped.")

finally:
    pynvml.nvmlShutdown()