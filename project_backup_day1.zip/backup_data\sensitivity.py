import numpy as np
import pandas as pd
import sim_router as S

S.WQ = 20
S.T_GUARD = 999
S.GUARD_MODE = "hard"

SEEDS = range(300, 310)          # fresh seeds, never used before
PATS = ["steady", "bursty", "moderate", "high"]
POLS = ["least_load", "reactive", "predictive"]
TCRIT = 2.262                    # 95%, 9 degrees of freedom

ORIG = {k: dict(v) for k, v in S.CONFIGS.items()}

SPREADS = {
    "identical": {"nodeA": dict(cool_scale=1.00, amb_offset=1.0),
                  "nodeB": dict(cool_scale=1.00, amb_offset=1.0),
                  "nodeC": dict(cool_scale=1.00, amb_offset=1.0)},
    "small":     {"nodeA": dict(cool_scale=1.10, amb_offset=0.5),
                  "nodeB": dict(cool_scale=1.00, amb_offset=1.0),
                  "nodeC": dict(cool_scale=0.90, amb_offset=1.5)},
    "default":   ORIG,
    "large":     {"nodeA": dict(cool_scale=1.50, amb_offset=0.0),
                  "nodeB": dict(cool_scale=1.00, amb_offset=1.0),
                  "nodeC": dict(cool_scale=0.65, amb_offset=3.0)},
}

def set_cfg(cfg):
    for k, v in cfg.items():
        S.CONFIGS[k] = dict(v)

jobs = []
for sp in SPREADS:
    jobs.append((sp, 70.0))
jobs += [("default", 65.0), ("default", 75.0)]

rows = []
for sp, ts in jobs:
    set_cfg(SPREADS[sp])
    S.T_SOFT = ts
    for pat in PATS:
        for pol in POLS:
            for sd in SEEDS:
                r = S.run(pol, pat, sd)
                r["spread"] = sp
                r["tsoft"] = ts
                r["pol"] = pol
                r["pat"] = pat
                r["sd"] = sd
                rows.append(r)
    print(sp, ts, "done", flush=True)

set_cfg(ORIG)
S.T_SOFT = 70.0

df = pd.DataFrame(rows)
df = df[[c for c in df.columns if not c.startswith("share_")]]
df.to_csv("sens_runs.csv", index=False)

M = ["p99_T", "max_T", "imbalance_C", "p95_ms", "J_per_req"]

def paired(d, a, b, m):
    p = d.pivot(index="sd", columns="pol", values=m)
    x = (p[a] - p[b]).values
    ci = TCRIT * x.std(ddof=1) / np.sqrt(len(x))
    return f"{x.mean():+.2f}+/-{ci:.2f}"

print("\n=== PAIRED DIFFERENCES (seeds 300-309), negative = A lower ===")
for sp in SPREADS:
    print("\nSPREAD:", sp)
    for pat in PATS:
        d = df[(df.spread == sp) & (df.tsoft == 70.0) & (df.pat == pat)]
        for a, b in [("reactive", "least_load"), ("predictive", "least_load"), ("predictive", "reactive")]:
            vals = "  ".join(f"{m}={paired(d, a, b, m)}" for m in M)
            print(f"{pat:9s} {a}-{b}: {vals}")

print("\n=== T_SOFT sensitivity, default spread, mean viol_pct ===")
d = df[df.spread == "default"]
print(d.groupby(["pat", "tsoft", "pol"])["viol_pct"].mean().round(2).unstack("pol").to_string())

print("\nSaved sens_runs.csv")