import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error

LAG = 5
FEATURES = ["temperature_c", "gpu_utilization_percent", "memory_utilization_percent",
            "power_watts", "temp_lag", "temp_trend", "util_mean5", "power_mean5"]

df = pd.read_csv("gpu_telemetry.csv")
df["timestamp"] = pd.to_datetime(df["timestamp"])
df = df.reset_index(drop=True)

is_cyc = df["workload_type"] == "cycling_heavy_idle"
first_busy = df.index[is_cyc & (df["gpu_utilization_percent"] >= 50)].min()
df.loc[is_cyc & (df.index < first_busy), "workload_type"] = "idle_long"

gap = df["timestamp"].diff().dt.total_seconds()
new_seg = gap.isna() | (gap > 3) | (df["workload_type"] != df["workload_type"].shift())
df["segment"] = new_seg.cumsum()

def build(H):
    frames = []
    for seg, g in df.groupby("segment"):
        g = g.copy()
        g["temp_lag"] = g["temperature_c"].shift(LAG)
        g["temp_trend"] = g["temperature_c"] - g["temp_lag"]
        g["util_mean5"] = g["gpu_utilization_percent"].rolling(LAG).mean()
        g["power_mean5"] = g["power_watts"].rolling(LAG).mean()
        g["future"] = g["temperature_c"].shift(-H)
        frames.append(g.dropna(subset=FEATURES + ["future"]))
    return frames

def split(frames, H):
    tr, te = [], []
    for g in frames:
        if len(g) < 50:
            tr.append(g)
            continue
        k = int(len(g) * 0.8)
        tr.append(g.iloc[:max(k - H, 0)])
        te.append(g.iloc[k:])
    return pd.concat(tr), pd.concat(te)

out = []
for H in [5, 10, 30]:
    train, test = split(build(H), H)
    ytr = train["future"] - train["temperature_c"]
    lin = LinearRegression().fit(train[FEATURES], ytr)
    rf = RandomForestRegressor(n_estimators=200, random_state=42, n_jobs=-1).fit(train[FEATURES], ytr)
    test = test.copy()
    test["naive"] = test["temperature_c"]
    test["linear"] = test["temperature_c"] + lin.predict(test[FEATURES])
    test["rf"] = test["temperature_c"] + rf.predict(test[FEATURES])

    def row(name, t):
        return {"H": H, "subset": name, "n": len(t),
                "naive": mean_absolute_error(t["future"], t["naive"]),
                "linear": mean_absolute_error(t["future"], t["linear"]),
                "rf": mean_absolute_error(t["future"], t["rf"])}

    for label, t in test.groupby("workload_type"):
        out.append(row(label, t))
    out.append(row("DYNAMIC (|trend|>=2)", test[test["temp_trend"].abs() >= 2]))
    out.append(row("ALL", test))

res = pd.DataFrame(out).round(3)
print(res.to_string(index=False))
res.to_csv("model_breakdown.csv", index=False)
print("\nSaved model_breakdown.csv")