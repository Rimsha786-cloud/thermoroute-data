import argparse
import os
import threading
import time

os.add_dll_directory(r"C:\Windows\System32")

import pynvml
import torch
from fastapi import FastAPI
import uvicorn

from emulator import load_params, NodeThermal

parser = argparse.ArgumentParser()
parser.add_argument("--port", type=int, required=True)
parser.add_argument("--node-id", type=str, required=True)
parser.add_argument("--cool-scale", type=float, required=True)
parser.add_argument("--amb-offset", type=float, required=True)
parser.add_argument("--seed", type=int, default=1)
args = parser.parse_args()

P_IDLE = 30.0
P_MAX = 575.0

pynvml.nvmlInit()
handle = pynvml.nvmlDeviceGetHandleByIndex(0)

device = torch.device("cuda")
SIZE = 8192
a = torch.randn((SIZE, SIZE), device=device, dtype=torch.float16)
b = torch.randn((SIZE, SIZE), device=device, dtype=torch.float16)

PARAMS = load_params("2-part+fan")
thermal = NodeThermal(
    PARAMS,
    cool_scale=args.cool_scale,
    amb_offset=args.amb_offset,
    noise_sd=0.3,
    seed=args.seed,
    t_init=30.0,
)

counter_lock = threading.Lock()
snap_lock = threading.Lock()
infer_lock = threading.Lock()

busy_seconds = 0.0
served = 0
waiting = 0
active = 0
last_step = time.time()

snapshot = {
    "node_id": args.node_id,
    "temp_c": float(thermal.T1),
    "power_est_w": P_IDLE,
    "queue": 0,
    "busy": 0,
    "served": 0,
    "real_gpu_temp_c": None,
    "real_gpu_util_percent": None,
    "real_gpu_power_w": None,
}


def telemetry_loop():
    global busy_seconds, last_step

    while True:
        time.sleep(1.0)
        now = time.time()
        dt = max(0.1, now - last_step)
        last_step = now

        with counter_lock:
            bsec = busy_seconds
            busy_seconds = 0.0
            q = waiting
            act = active
            s = served

        busy_frac = min(1.0, bsec / dt)
        power_est = P_IDLE + busy_frac * (P_MAX - P_IDLE)

        thermal.step(dt, power_est)
        temp_c = float(thermal.read_temp())

        try:
            real_temp = int(pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU))
            util = pynvml.nvmlDeviceGetUtilizationRates(handle)
            real_util = int(util.gpu)
            real_power = float(pynvml.nvmlDeviceGetPowerUsage(handle) / 1000.0)
        except Exception:
            real_temp, real_util, real_power = None, None, None

        with snap_lock:
            snapshot.update({
                "node_id": args.node_id,
                "temp_c": temp_c,
                "power_est_w": round(float(power_est), 2),
                "queue": int(q + act),
                "busy": int(act),
                "served": int(s),
                "real_gpu_temp_c": real_temp,
                "real_gpu_util_percent": real_util,
                "real_gpu_power_w": real_power,
            })


app = FastAPI()


@app.get("/health")
def health():
    return {"node_id": args.node_id, "status": "ok"}


@app.get("/telemetry")
def telemetry():
    with snap_lock:
        return dict(snapshot)


@app.post("/infer")
def infer():
    global busy_seconds, served, waiting, active

    with counter_lock:
        waiting += 1

    with infer_lock:
        with counter_lock:
            waiting -= 1
            active = 1

        start = time.time()
        try:
            for _ in range(30):
                c = torch.matmul(a, b)
            torch.cuda.synchronize()
        finally:
            elapsed = time.time() - start
            with counter_lock:
                busy_seconds += elapsed
                served += 1
                active = 0

    with snap_lock:
        temp_c = snapshot["temp_c"]

    return {
        "node_id": args.node_id,
        "status": "completed",
        "latency_ms": round(elapsed * 1000, 2),
        "temp_c": temp_c,
    }


if __name__ == "__main__":
    threading.Thread(target=telemetry_loop, daemon=True).start()
    uvicorn.run(app, host="127.0.0.1", port=args.port)