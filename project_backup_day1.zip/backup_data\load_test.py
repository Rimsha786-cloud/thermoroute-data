﻿import requests
import time

start = time.time()
for i in range(100):
    requests.post("http://127.0.0.1:8003/infer")

elapsed = time.time() - start
print(f"Done sending requests. Total time: {elapsed:.2f}s")
