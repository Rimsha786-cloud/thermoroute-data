import torch
import time

device = torch.device("cuda")

print("GPU:", torch.cuda.get_device_name(0))
print("Starting MEDIUM GPU workload...")

size = 6144
a = torch.randn((size, size), device=device, dtype=torch.float16)
b = torch.randn((size, size), device=device, dtype=torch.float16)

while True:
    c = torch.matmul(a, b)
    torch.cuda.synchronize()
    time.sleep(0.05)