import json
import numpy as np
import pandas as pd
from scipy.optimize import least_squares

SUB = 5

def run(x, P, T1, T2=None):
    Tamb = x[0]
    R1, C1, R2, C2 = np.exp(x[1:5])
    a = x[5]
    dt = 1.0 / SUB
    if T2 is None:
        T2 = max(Tamb, T1 - R1 * P[0])
    out = np.empty(len(P))
    for i, p in enumerate(P):
        out[i] = T1
        for _ in range(SUB):
            q12 = (T1 - T2) / R1
            g2 = (1 + a * max(T2 - Tamb, 0.0) / 50.0) / R2
            T1 += dt * (p - q12) / C1
            T2 += dt * (q12 - (T2 - Tamb) * g2) / C2
    return out

def track_T2(x, T, P):
    Tamb = x[0]
    R1, C1, R2, C2 = np.exp(x[1:5])
    a = x[5]
    dt = 1.0 / SUB
    T2 = max(Tamb, T[0] - R1 * P[0])
    T2s = np.empty(len(T))
    for i in range(len(T)):
        T2s[i] = T2
        T1 = T[i]
        for _ in range(SUB):
            q12 = (T1 - T2) / R1
            g2 = (1 + a * max(T2 - Tamb, 0.0) / 50.0) / R2
            T1 += dt * (P[i] - q12) / C1
            T2 += dt * (q12 - (T2 - Tamb) * g2) / C2
    return T2s

def segments(df, by_label):
    gap = df["timestamp"].diff().dt.total_seconds()
    new = gap.isna() | (gap > 3)
    if by_label:
        new = new | (df["workload_type"] != df["workload_type"].shift())
    out = []
    for _, g in df.groupby(new.cumsum()):
        if len(g) >= 10:
            out.append((g["temperature_c"].values.astype(float), g["power_watts"].values.astype(float)))
    return out

old = pd.read_csv("gpu_telemetry.csv")
old["timestamp"] = pd.to_datetime(old["timestamp"])
old = old.reset_index(drop=True)
is_cyc = old["workload_type"] == "cycling_heavy_idle"
fb = old.index[is_cyc & (old["gpu_utilization_percent"] >= 50)].min()
old.loc[is_cyc & (old.index < fb), "workload_type"] = "idle_long"
train_segs = segments(old, True)

new = pd.read_csv("gpu_telemetry_random.csv")
new["timestamp"] = pd.to_datetime(new["timestamp"])
new = new.reset_index(drop=True)
test_segs = segments(new, False)
Tt, Pt = test_segs[0]
phase = new["phase"].values

base = np.array(json.load(open("rc_params.json"))["model2"]["x"])

def fit(free_a):
    z0 = np.append(base, 1.0) if free_a else base.copy()
    lo = [10, np.log(0.001), np.log(1), np.log(0.001), np.log(1)] + ([0.0] if free_a else [])
    hi = [40, np.log(2), np.log(1e5), np.log(2), np.log(1e6)] + ([10.0] if free_a else [])
    full = (lambda z: z) if free_a else (lambda z: np.append(z, 0.0))
    def res(z):
        x = full(z)
        return np.concatenate([run(x, P, T[0]) - T for T, P in train_segs])
    r = least_squares(res, z0, bounds=(lo, hi))
    return full(r.x)

def stats(e):
    e = np.asarray(e)
    return np.round([np.abs(e).mean(), np.sqrt((e ** 2).mean()), np.abs(e).max()], 2)

def full_err(x, segs):
    return stats(np.concatenate([run(x, P, T[0]) - T for T, P in segs]))

def win_err(x, segs, W=60):
    errs = []
    for T, P in segs:
        for s in range(0, len(T) - W, W):
            errs.append(run(x, P[s:s + W], T[s]) - T[s:s + W])
    return stats(np.concatenate(errs))

models = {}
print("Fitting 2-part (no fan term) ...")
models["2-part"] = fit(False)
print("Fitting 2-part + fan term ...")
models["2-part+fan"] = fit(True)

for name, x in models.items():
    print(f"\n{name}: Tamb={x[0]:.1f} R1={np.exp(x[1]):.4f} C1={np.exp(x[2]):.1f} "
          f"R2={np.exp(x[3]):.4f} C2={np.exp(x[4]):.1f} fan_a={x[5]:.2f}")
    ss = x[0] + 575 * (np.exp(x[1]) + np.exp(x[3]))
    print(f"  (rough steady heavy temp without fan effect: {ss:.1f} C)")
    print("  errors MAE, RMSE, max")
    print("  TRAIN full-run   :", full_err(x, train_segs))
    print("  TEST  full-run   :", full_err(x, test_segs))
    print("  TEST  60s windows:", win_err(x, test_segs))

print("\n=== FORECAST on random run (model given true future power) ===")
rows = []
for name, x in models.items():
    T2s = track_T2(x, Tt, Pt)
    for H in [10, 30]:
        idx = np.arange(5, len(Tt) - H)
        pred = np.array([run(x, np.append(Pt[i:i + H], Pt[i + H - 1]), Tt[i], T2s[i])[H] for i in idx])
        true = Tt[idx + H]
        naive = Tt[idx]
        dyn = np.abs(Tt[idx] - Tt[idx - 5]) >= 2
        ph = phase[idx]
        row = {"model": name, "H": H, "ALL_model": np.abs(pred - true).mean(), "ALL_naive": np.abs(naive - true).mean(),
               "DYN_model": np.abs(pred - true)[dyn].mean(), "DYN_naive": np.abs(naive - true)[dyn].mean(), "n_dyn": int(dyn.sum())}
        for p in ["heavy", "medium", "idle"]:
            m = ph == p
            row[p + "_model"] = np.abs(pred - true)[m].mean()
            row[p + "_naive"] = np.abs(naive - true)[m].mean()
        rows.append(row)
res = pd.DataFrame(rows).round(2)
print(res.to_string(index=False))
res.to_csv("rc_forecast_eval.csv", index=False)

json.dump({k: v.tolist() for k, v in models.items()}, open("rc_params2.json", "w"), indent=2)
print("\nSaved rc_params2.json and rc_forecast_eval.csv")

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.figure(figsize=(11, 4))
    plt.plot(Tt, label="measured")
    for name, x in models.items():
        W = 60
        pr = np.concatenate([run(x, Pt[s:s + W], Tt[s]) for s in range(0, len(Tt) - W, W)])
        plt.plot(pr, label=name + " (60s windows)")
    plt.xlabel("time (s)"); plt.ylabel("temperature (C)"); plt.legend(); plt.tight_layout()
    plt.savefig("rc_test_fit.png", dpi=150)
    print("Saved rc_test_fit.png")
except Exception as e:
    print("Plot skipped:", e)