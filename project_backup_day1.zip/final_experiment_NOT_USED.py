import numpy as np
import pandas as pd
from scipy import stats
import sim_router as S

SEEDS = range(200, 210)          # fresh seeds, never used for tuning
PATS = ["steady", "bursty", "moderate", "high"]
BASE = dict(WQ=20, T_GUARD=999, GUARD_MODE="hard")   # guard off
CFG = [
    ("round_robin",        "round_robin",    {}),
    ("least_load",         "least_load",     {}),
    ("reactive",           "reactive",       {}),
    ("predictive_raw",     "predictive_raw", {}),
    ("ThermoRoute",        "predictive",     {}),
    ("ThermoRoute+guard68", "predictive",    dict(T_GUARD=68, GUARD_MODE="hard")),
]
METRICS = ["p99_T", "max_T", "imbalance_C", "p95_ms", "thr_rps", "J_per_req"]

rows = []
for pat in PATS:
    for sd in SEEDS:
        for name, pol, over in CFG:
            for k, v in BASE.items():
                setattr(S, k, v)
            for k, v in over.items():
                setattr(S, k, v)
            r = S.run(pol, pat, sd)
            r["config"] = name
            rows.append(r)
    print(pat, "done", flush=True)

df = pd.DataFrame(rows)
df.to_csv("final_runs.csv", index=False)

pd.set_option("display.width", 250)
print("\nMEANS over 10 fresh seeds")
print(df.groupby(["pattern", "config"])[METRICS].mean().round(2).to_string())

print("\nPAIRED DIFFERENCE vs least_load (same seed, same arrivals), mean ± 95% CI")
out = []
for pat in PATS:
    base = df[(df.pattern == pat) & (df.config == "least_load")].set_index("seed")
    for name, _, _ in CFG:
        if name == "least_load":
            continue
        c = df[(df.pattern == pat) & (df.config == name)].set_index("seed")
        row = {"pattern": pat, "config": name}
        for m in METRICS:
            d = (c[m] - base[m]).values
            ci = stats.t.ppf(0.975, len(d) - 1) * d.std(ddof=1) / np.sqrt(len(d))
            row[m] = f"{d.mean():+.2f}±{ci:.2f}"
        out.append(row)
print(pd.DataFrame(out).to_string(index=False))
print("\nSaved final_runs.csv")