import pandas as pd
import numpy as np
import joblib
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

LAG = 5
HORIZONS = [5, 10, 30]
FEATURES = ["temperature_c", "gpu_utilization_percent", "memory_utilization_percent",
            "power_watts", "temp_lag", "temp_trend", "util_mean5", "power_mean5"]

df = pd.read_csv("gpu_telemetry.csv")
df["timestamp"] = pd.to_datetime(df["timestamp"])
df = df.reset_index(drop=True)

print("Labels BEFORE cleaning:")
print(df["workload_type"].value_counts())

# 1) Relabel flat idle rows at the start of cycling_heavy_idle
is_cyc = df["workload_type"] == "cycling_heavy_idle"
busy = df.index[is_cyc & (df["gpu_utilization_percent"] >= 50)]
first_busy = busy.min()
flat = is_cyc & (df.index < first_busy)
print("\nRows relabelled cycling_heavy_idle -> idle_long:", int(flat.sum()))
df.loc[flat, "workload_type"] = "idle_long"

# 2) Continuous segments (new segment on label change or time gap > 3 s)
gap = df["timestamp"].diff().dt.total_seconds()
new_seg = gap.isna() | (gap > 3) | (df["workload_type"] != df["workload_type"].shift())
df["segment"] = new_seg.cumsum()

print("\nLabels AFTER cleaning:")
print(df["workload_type"].value_counts())
print("\nSegments:")
print(df.groupby("segment").agg(label=("workload_type", "first"), rows=("temperature_c", "size"),
      tmin=("temperature_c", "min"), tmax=("temperature_c", "max")).to_string())

def build(H):
    frames = []
    for seg, g in df.groupby("segment"):
        g = g.copy()
        g["temp_lag"] = g["temperature_c"].shift(LAG)
        g["temp_trend"] = g["temperature_c"] - g["temp_lag"]
        g["util_mean5"] = g["gpu_utilization_percent"].rolling(LAG).mean()
        g["power_mean5"] = g["power_watts"].rolling(LAG).mean()
        g["future"] = g["temperature_c"].shift(-H)
        g = g.dropna(subset=FEATURES + ["future"])
        frames.append(g)
    return frames

def split(frames, H):
    tr, te = [], []
    for g in frames:
        if len(g) < 50:
            tr.append(g)
            continue
        k = int(len(g) * 0.8)
        tr.append(g.iloc[:max(k - H, 0)])
        te.append(g.iloc[k:])
    return pd.concat(tr), pd.concat(te)

def score(y, p):
    return (mean_absolute_error(y, p), mean_squared_error(y, p) ** 0.5, r2_score(y, p))

rows = []
for H in HORIZONS:
    frames = build(H)
    train, test = split(frames, H)
    Xtr, Xte = train[FEATURES], test[FEATURES]
    ytr = train["future"] - train["temperature_c"]
    yte = test["future"]

    naive = test["temperature_c"].values
    lin = LinearRegression().fit(Xtr, ytr)
    lin_p = test["temperature_c"].values + lin.predict(Xte)
    rf = RandomForestRegressor(n_estimators=200, random_state=42, n_jobs=-1).fit(Xtr, ytr)
    rf_p = test["temperature_c"].values + rf.predict(Xte)

    print(f"\n=== Horizon {H}s | train rows {len(train)} | test rows {len(test)} ===")
    for name, p in [("naive", naive), ("linear", lin_p), ("rf", rf_p)]:
        mae, rmse, r2 = score(yte, p)
        print(f"{name:7s} MAE {mae:.3f}  RMSE {rmse:.3f}  R2 {r2:.3f}")
        rows.append({"horizon_s": H, "model": name, "MAE": mae, "RMSE": rmse, "R2": r2,
                     "train_rows": len(train), "test_rows": len(test)})

    joblib.dump({"model": rf, "features": FEATURES, "horizon": H, "lag": LAG, "target": "delta"},
                f"temp_rf_h{H}.pkl")
    if H == 10:
        imp = pd.Series(rf.feature_importances_, index=FEATURES).sort_values(ascending=False)
        print("\nRF feature importances (10 s):")
        print(imp.to_string())

pd.DataFrame(rows).to_csv("model_results.csv", index=False)
print("\nSaved model_results.csv and temp_rf_h5.pkl / temp_rf_h10.pkl / temp_rf_h30.pkl")